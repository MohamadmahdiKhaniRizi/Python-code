import tkinter as tk
from tkinter import ttk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
import time
import random

class Pendulum:
    def __init__(self, length=1.0, mass=0.1, gravity=9.81):
        self.length = length
        self.mass = mass
        self.gravity = gravity
        self.angle = np.pi  # rad (straight up)
        self.angular_velocity = 0.0

    def update(self, cart_acceleration, dt):
        g = self.gravity
        l = self.length
        theta = self.angle
        omega = self.angular_velocity
        accel = (g / l) * np.sin(theta) + (cart_acceleration / l) * np.cos(theta)
        self.angular_velocity += accel * dt
        self.angle += self.angular_velocity * dt
        return self.angle, self.angular_velocity

    def get_state(self):
        return self.angle, self.angular_velocity

class Cart:
    def __init__(self, mass=1.0, force=10.0):
        self.mass = mass
        self.force = force
        self.position = 0.0
        self.velocity = 0.0

    def update(self, control_force, dt):
        accel = control_force / self.mass
        self.velocity += accel * dt
        self.position += self.velocity * dt
        return self.position, self.velocity

    def get_state(self):
        return self.position, self.velocity

class Controller:
    def __init__(self, kp=50.0, ki=0.0, kd=10.0, setpoint=0.0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.setpoint = setpoint
        self.integral = 0.0
        self.prev_error = 0.0
        self.dt = 0.01
        self.max_force = 20.0

    def compute(self, measured_angle, dt):
        error = self.setpoint - measured_angle
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        output = max(-self.max_force, min(self.max_force, output))
        return output

    def set_pid(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd

class Simulation:
    def __init__(self, pendulum, cart, controller, dt=0.01):
        self.pendulum = pendulum
        self.cart = cart
        self.controller = controller
        self.dt = dt
        self.time = 0.0
        self.time_data = []
        self.angle_data = []
        self.cart_pos_data = []
        self.force_data = []
        self.running = False
        self.paused = False
        self.mode = "AUTO"  # AUTO or MANUAL
        self.manual_force = 0.0
        self.noise_std = 0.0  # sensor noise

    def set_noise(self, std):
        self.noise_std = std

    def set_mode(self, mode):
        self.mode = mode

    def apply_manual_force(self, force):
        self.manual_force = force

    def step(self):
        # Sensor reading with noise
        measured_angle = self.pendulum.angle + random.gauss(0, self.noise_std)
        measured_pos = self.cart.position + random.gauss(0, self.noise_std * 0.1)

        if self.mode == "AUTO":
            force = self.controller.compute(measured_angle, self.dt)
        else:
            force = self.manual_force

        # Cart update
        self.cart.update(force, self.dt)
        # Pendulum update (uses cart acceleration, not force)
        cart_accel = force / self.cart.mass
        self.pendulum.update(cart_accel, self.dt)

        self.time += self.dt
        self.time_data.append(self.time)
        self.angle_data.append(self.pendulum.angle)
        self.cart_pos_data.append(self.cart.position)
        self.force_data.append(force)

    def run(self, duration):
        self.running = True
        while self.running and self.time < duration:
            if not self.paused:
                self.step()
            time.sleep(self.dt)

    def stop(self):
        self.running = False

    def reset(self):
        self.pendulum.angle = np.pi
        self.pendulum.angular_velocity = 0.0
        self.cart.position = 0.0
        self.cart.velocity = 0.0
        self.time = 0.0
        self.time_data.clear()
        self.angle_data.clear()
        self.cart_pos_data.clear()
        self.force_data.clear()

class InvertedPendulumGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Inverted Pendulum Balance Game")
        self.root.geometry("1100x750")
        self.root.resizable(False, False)

        self.pendulum = Pendulum()
        self.cart = Cart()
        self.controller = Controller()
        self.sim = Simulation(self.pendulum, self.cart, self.controller)
        self.sim.set_mode("AUTO")

        self.running = False
        self.thread = None
        self.keys_pressed = set()

        self.setup_ui()
        self.update_plot()
        self.root.bind('<KeyPress>', self.key_press)
        self.root.bind('<KeyRelease>', self.key_release)

    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Canvas for animation
        self.canvas = tk.Canvas(left_frame, width=600, height=400, bg="white")
        self.canvas.pack(pady=10)

        # Plot for angle over time
        self.fig, self.ax = plt.subplots(figsize=(5, 3))
        self.ax.set_title("Angle vs Time")
        self.ax.set_xlabel("Time (s)")
        self.ax.set_ylabel("Angle (rad)")
        self.ax.grid(True)
        self.canvas_plot = FigureCanvasTkAgg(self.fig, master=left_frame)
        self.canvas_plot.get_tk_widget().pack()

        right_frame = ttk.Frame(main_frame, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(right_frame, text="Inverted Pendulum Control", font=("Arial", 14, "bold")).pack(pady=5)

        # Mode selection
        mode_frame = ttk.LabelFrame(right_frame, text="Control Mode")
        mode_frame.pack(fill=tk.X, pady=5)
        self.mode_var = tk.StringVar(value="AUTO")
        ttk.Radiobutton(mode_frame, text="Auto (PID)", variable=self.mode_var, value="AUTO", command=self.set_mode).pack(anchor="w")
        ttk.Radiobutton(mode_frame, text="Manual (Arrow Keys)", variable=self.mode_var, value="MANUAL", command=self.set_mode).pack(anchor="w")

        # PID parameters
        pid_frame = ttk.LabelFrame(right_frame, text="PID Gains")
        pid_frame.pack(fill=tk.X, pady=5)
        ttk.Label(pid_frame, text="Kp:").grid(row=0, column=0, padx=2)
        self.kp_var = tk.DoubleVar(value=50.0)
        ttk.Entry(pid_frame, width=8, textvariable=self.kp_var).grid(row=0, column=1)
        ttk.Label(pid_frame, text="Ki:").grid(row=1, column=0, padx=2)
        self.ki_var = tk.DoubleVar(value=0.0)
        ttk.Entry(pid_frame, width=8, textvariable=self.ki_var).grid(row=1, column=1)
        ttk.Label(pid_frame, text="Kd:").grid(row=2, column=0, padx=2)
        self.kd_var = tk.DoubleVar(value=10.0)
        ttk.Entry(pid_frame, width=8, textvariable=self.kd_var).grid(row=2, column=1)
        ttk.Button(pid_frame, text="Update PID", command=self.update_pid).grid(row=3, column=0, columnspan=2, pady=5)

        # Noise control
        noise_frame = ttk.LabelFrame(right_frame, text="Sensor Noise")
        noise_frame.pack(fill=tk.X, pady=5)
        self.noise_var = tk.DoubleVar(value=0.0)
        noise_scale = ttk.Scale(noise_frame, from_=0.0, to=0.5, variable=self.noise_var, orient=tk.HORIZONTAL, command=self.update_noise)
        noise_scale.pack(fill=tk.X)
        self.lbl_noise = ttk.Label(noise_frame, text="Std: 0.00")
        self.lbl_noise.pack()

        # Simulation controls
        ctrl_frame = ttk.Frame(right_frame)
        ctrl_frame.pack(fill=tk.X, pady=10)
        self.btn_start = ttk.Button(ctrl_frame, text="Start", command=self.start_sim)
        self.btn_start.pack(side=tk.LEFT, padx=2)
        self.btn_pause = ttk.Button(ctrl_frame, text="Pause", command=self.pause_sim, state=tk.DISABLED)
        self.btn_pause.pack(side=tk.LEFT, padx=2)
        self.btn_stop = ttk.Button(ctrl_frame, text="Stop", command=self.stop_sim, state=tk.DISABLED)
        self.btn_stop.pack(side=tk.LEFT, padx=2)
        self.btn_reset = ttk.Button(ctrl_frame, text="Reset", command=self.reset_sim)
        self.btn_reset.pack(side=tk.LEFT, padx=2)

        # Status display
        status_frame = ttk.LabelFrame(right_frame, text="Status")
        status_frame.pack(fill=tk.X, pady=5)
        self.lbl_angle = ttk.Label(status_frame, text="Angle: 180.0°")
        self.lbl_angle.pack(anchor="w")
        self.lbl_velocity = ttk.Label(status_frame, text="Angular Vel: 0.00 rad/s")
        self.lbl_velocity.pack(anchor="w")
        self.lbl_pos = ttk.Label(status_frame, text="Cart Pos: 0.00 m")
        self.lbl_pos.pack(anchor="w")
        self.lbl_force = ttk.Label(status_frame, text="Force: 0.00 N")
        self.lbl_force.pack(anchor="w")
        self.lbl_mode = ttk.Label(status_frame, text="Mode: AUTO")
        self.lbl_mode.pack(anchor="w")

        self.draw_scene()

    def draw_scene(self):
        self.canvas.delete("all")
        W = 600
        H = 400
        ground_y = 350
        cart_x = 300 + self.cart.position * 50
        cart_width = 60
        cart_height = 30
        self.canvas.create_rectangle(0, ground_y, W, ground_y+10, fill="gray", outline="black")
        cart = self.canvas.create_rectangle(cart_x - cart_width/2, ground_y - cart_height,
                                           cart_x + cart_width/2, ground_y,
                                           fill="blue", outline="black")
        pivot_x = cart_x
        pivot_y = ground_y - cart_height
        angle = self.pendulum.angle - np.pi/2  # for drawing from vertical up
        length = 150
        end_x = pivot_x + length * np.cos(angle)
        end_y = pivot_y - length * np.sin(angle)
        self.canvas.create_line(pivot_x, pivot_y, end_x, end_y, fill="red", width=4)
        self.canvas.create_oval(pivot_x-5, pivot_y-5, pivot_x+5, pivot_y+5, fill="black")
        self.canvas.create_oval(end_x-8, end_y-8, end_x+8, end_y+8, fill="red")
        # Display angle in degrees
        deg = np.degrees(self.pendulum.angle)
        self.canvas.create_text(50, 30, text=f"Angle: {deg:.1f}°", font=("Arial", 12))

    def update_plot(self):
        if self.sim.time_data:
            self.ax.clear()
            self.ax.plot(self.sim.time_data, self.sim.angle_data, 'b-', label="Angle")
            self.ax.set_title("Angle vs Time")
            self.ax.set_xlabel("Time (s)")
            self.ax.set_ylabel("Angle (rad)")
            self.ax.grid(True)
            self.canvas_plot.draw()

    def update_status(self):
        deg = np.degrees(self.pendulum.angle)
        self.lbl_angle.config(text=f"Angle: {deg:.1f}°")
        self.lbl_velocity.config(text=f"Angular Vel: {self.pendulum.angular_velocity:.2f} rad/s")
        self.lbl_pos.config(text=f"Cart Pos: {self.cart.position:.2f} m")
        self.lbl_force.config(text=f"Force: {self.sim.force_data[-1] if self.sim.force_data else 0:.2f} N")
        self.lbl_mode.config(text=f"Mode: {self.mode_var.get()}")

    def set_mode(self):
        mode = self.mode_var.get()
        self.sim.set_mode(mode)
        self.lbl_mode.config(text=f"Mode: {mode}")

    def update_pid(self):
        self.controller.set_pid(self.kp_var.get(), self.ki_var.get(), self.kd_var.get())

    def update_noise(self, val):
        std = self.noise_var.get()
        self.sim.set_noise(std)
        self.lbl_noise.config(text=f"Std: {std:.2f}")

    def key_press(self, event):
        if event.keysym in ('Left', 'Right'):
            self.keys_pressed.add(event.keysym)
            if self.sim.mode == "MANUAL":
                force = 5.0 if event.keysym == 'Right' else -5.0
                self.sim.apply_manual_force(force)

    def key_release(self, event):
        if event.keysym in ('Left', 'Right'):
            self.keys_pressed.discard(event.keysym)
            if self.sim.mode == "MANUAL" and not self.keys_pressed:
                self.sim.apply_manual_force(0.0)

    def start_sim(self):
        if not self.running:
            self.running = True
            self.sim.running = True
            self.btn_start.config(state=tk.DISABLED)
            self.btn_pause.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.NORMAL)
            self.thread = threading.Thread(target=self.sim.run, args=(30,), daemon=True)
            self.thread.start()
            self.update_loop()

    def update_loop(self):
        if self.running:
            self.draw_scene()
            self.update_status()
            self.update_plot()
            self.root.after(50, self.update_loop)

    def pause_sim(self):
        self.sim.paused = not self.sim.paused
        self.btn_pause.config(text="Resume" if self.sim.paused else "Pause")

    def stop_sim(self):
        self.running = False
        self.sim.stop()
        self.btn_start.config(state=tk.NORMAL)
        self.btn_pause.config(state=tk.DISABLED, text="Pause")
        self.btn_stop.config(state=tk.DISABLED)

    def reset_sim(self):
        self.stop_sim()
        self.sim.reset()
        self.draw_scene()
        self.update_status()
        self.ax.clear()
        self.canvas_plot.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = InvertedPendulumGUI(root)
    root.mainloop()