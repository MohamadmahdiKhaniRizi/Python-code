def harmonic(num):
    sum = 0.0
    for a in range(1, num + 1):
        sum += 1.0 / a
    return sum

print("harmonic:",harmonic(1))
print("harmonic:",harmonic(2))
print("harmonic:",harmonic(3))
print("harmonic:",harmonic(4))
print("harmonic:",harmonic(5))
print("harmonic:",harmonic(6))
print("harmonic:",harmonic(7))
print("harmonic:",harmonic(8))
print("harmonic:",harmonic(9))
print("harmonic:",harmonic(10))