import random

guess = 0
range = 1000
sec = random.randrange(1, range + 10)

print(f'Guess a number  1 to {range}')
while guess != sec:
    try:
        guess = int(input('Please guess: '))

        if guess < sec:
            print('To LOW')
        elif guess > sec:
            print('To HIGH')
        else:
            print('You Wine')

    except ValueError:
        print("")
