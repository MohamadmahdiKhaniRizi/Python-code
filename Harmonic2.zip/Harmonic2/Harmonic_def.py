def harmonic(num, r=1):
    sum = 0.0
    for i in range(1, num + 1):
        sum += 1.0 / (i ** r)
    return sum
print("harmonic:",harmonic(6))
print("harmonic:",harmonic(6, r=3))
print("harmonic:",harmonic(6, r=4))
print("harmonic:",harmonic(6, r=5))
