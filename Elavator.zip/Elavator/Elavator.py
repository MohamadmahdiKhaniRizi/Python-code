import tkinter as tk
from tkinter import ttk, scrolledtext
import random
from collections import defaultdict

class Person:
    def __init__(self, pid, source_floor, dest_floor):
        self.id = pid
        self.source = source_floor
        self.destination = dest_floor
        self.wait_time = 0

    def __repr__(self):
        return f"P{self.id}({self.source}->{self.destination})"

class Elevator:
    def __init__(self, id, capacity=8):
        self.id = id
        self.capacity = capacity
        self.current_floor = 0
        self.direction = 0
        self.passengers = []
        self.is_doors_open = False

    def remaining_capacity(self):
        return self.capacity - len(self.passengers)

    def load_passenger(self, person):
        if self.remaining_capacity() > 0:
            self.passengers.append(person)
            return True
        return False

    def unload_passengers(self):
        remaining = [p for p in self.passengers if p.destination != self.current_floor]
        unloaded = len(self.passengers) - len(remaining)
        self.passengers = remaining
        return unloaded

    def move(self):
        if self.direction != 0:
            self.current_floor += self.direction

class Controller:
    def __init__(self, num_floors, elevator):
        self.num_floors = num_floors
        self.elevator = elevator
        self.waiting_queue = defaultdict(list)
        self.total_wait_time = 0
        self.max_wait_time = 0
        self.total_served = 0

    def add_request(self, source_floor, dest_floor, count=1):
        if not (0 <= source_floor < self.num_floors and 0 <= dest_floor < self.num_floors and source_floor != dest_floor):
            return False
        if count > self.elevator.capacity:
            return False
        for _ in range(count):
            person = Person(pid=random.randint(1000, 9999), source_floor=source_floor, dest_floor=dest_floor)
            self.waiting_queue[source_floor].append(person)
        return True

    def update_waiting_times(self):
        all_people = []
        for floor_list in self.waiting_queue.values():
            all_people.extend(floor_list)
        all_people.extend(self.elevator.passengers)
        for p in all_people:
            p.wait_time += 1
            if p.wait_time > self.max_wait_time:
                self.max_wait_time = p.wait_time

    def decide_direction(self):
        if not self.waiting_queue and not self.elevator.passengers:
            self.elevator.direction = 0
            return

        current = self.elevator.current_floor
        all_destinations = list(self.waiting_queue.keys()) + [p.destination for p in self.elevator.passengers]

        if self.elevator.direction == 0:
            has_up = any(f > current for f in all_destinations)
            has_down = any(f < current for f in all_destinations)
            if has_up and not has_down:
                self.elevator.direction = 1
            elif has_down and not has_up:
                self.elevator.direction = -1
            elif has_up and has_down:
                self.elevator.direction = 1
            return

        if self.elevator.direction == 1:
            future_floors = [f for f in all_destinations if f > current]
            if not future_floors:
                self.elevator.direction = -1
        elif self.elevator.direction == -1:
            future_floors = [f for f in all_destinations if f < current]
            if not future_floors:
                self.elevator.direction = 1

    def step(self):
        elevator = self.elevator
        current = elevator.current_floor
        events = []

        self.update_waiting_times()

        if any(p.destination == current for p in elevator.passengers):
            unloaded = elevator.unload_passengers()
            events.append(f"Door opened at floor {current} | {unloaded} passenger(s) unloaded.")
            elevator.is_doors_open = True
        else:
            elevator.is_doors_open = False

        if current in self.waiting_queue:
            waiting_list = self.waiting_queue.pop(current)
            boarded = 0
            remaining = []
            for person in waiting_list:
                if elevator.load_passenger(person):
                    self.total_wait_time += person.wait_time
                    self.total_served += 1
                    boarded += 1
                    events.append(f"Passenger boarded: {person} (Waited {person.wait_time}s)")
                else:
                    remaining.append(person)
            if remaining:
                self.waiting_queue[current].extend(remaining)
            if boarded > 0:
                elevator.is_doors_open = True

        self.decide_direction()

        if elevator.direction != 0:
            elevator.move()
            events.append(f"Moved to floor {elevator.current_floor}")

        if not events:
            events.append("Waiting for new requests...")
        return events

    def get_average_wait_time(self):
        if self.total_served == 0:
            return 0.0
        return round(self.total_wait_time / self.total_served, 1)

class ElevatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Elevator Simulator (10 Floors)")
        self.root.geometry("850x700")
        self.root.resizable(False, False)

        self.num_floors = 10
        self.floor_height = 50
        self.elevator_width = 60
        self.canvas_height = self.num_floors * self.floor_height + 40
        self.canvas_width = 250

        self.elevator = Elevator(id=1, capacity=8)
        self.controller = Controller(num_floors=self.num_floors, elevator=self.elevator)

        self.source_var = tk.IntVar(value=0)
        self.dest_var = tk.IntVar(value=1)
        self.count_var = tk.IntVar(value=1)
        self.running = True

        self.setup_ui()
        self.simulate_step()

    def setup_ui(self):
        left_frame = ttk.Frame(self.root, padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(left_frame, width=self.canvas_width, height=self.canvas_height, bg="#f0f0f0", highlightthickness=2)
        self.canvas.pack(pady=10)

        for i in range(self.num_floors):
            y = self.canvas_height - 20 - (i * self.floor_height)
            self.canvas.create_line(30, y, self.canvas_width - 20, y, fill="gray", width=2)
            self.canvas.create_text(15, y, text=str(i), font=("Arial", 10, "bold"), anchor="e")

        self.shaft_x1 = 70
        self.shaft_x2 = self.shaft_x1 + self.elevator_width
        self.canvas.create_rectangle(self.shaft_x1-5, 10, self.shaft_x2+5, self.canvas_height-20, outline="black", width=2)

        self.elevator_rect = self.canvas.create_rectangle(
            self.shaft_x1, self.canvas_height - 20 - self.floor_height,
            self.shaft_x2, self.canvas_height - 20,
            fill="#2196F3", outline="black", width=3
        )
        self.elevator_text = self.canvas.create_text(
            (self.shaft_x1 + self.shaft_x2)//2,
            self.canvas_height - 20 - self.floor_height//2,
            text="🚀", font=("Arial", 14)
        )

        self.door_indicator = self.canvas.create_oval(
            self.shaft_x2 + 10, self.canvas_height - 30,
            self.shaft_x2 + 25, self.canvas_height - 15,
            fill="red", outline="black"
        )

        right_frame = ttk.Frame(self.root, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        status_frame = ttk.LabelFrame(right_frame, text="Live Status", padding=10)
        status_frame.pack(fill=tk.X, pady=5)

        self.lbl_floor = ttk.Label(status_frame, text="Floor: 0", font=("Arial", 11))
        self.lbl_floor.pack(anchor="w")
        self.lbl_dir = ttk.Label(status_frame, text="Direction: Stopped", font=("Arial", 11))
        self.lbl_dir.pack(anchor="w")
        self.lbl_passengers = ttk.Label(status_frame, text="Passengers: 0", font=("Arial", 11))
        self.lbl_passengers.pack(anchor="w")
        self.lbl_capacity = ttk.Label(status_frame, text="Capacity: 0/8", font=("Arial", 11))
        self.lbl_capacity.pack(anchor="w")

        stats_frame = ttk.LabelFrame(right_frame, text="Waiting Time Statistics", padding=10)
        stats_frame.pack(fill=tk.X, pady=5)

        self.lbl_avg_wait = ttk.Label(stats_frame, text="Average Wait: 0.0s", font=("Arial", 11))
        self.lbl_avg_wait.pack(anchor="w")
        self.lbl_max_wait = ttk.Label(stats_frame, text="Max Wait: 0s", font=("Arial", 11))
        self.lbl_max_wait.pack(anchor="w")
        self.lbl_served = ttk.Label(stats_frame, text="Served Passengers: 0", font=("Arial", 11))
        self.lbl_served.pack(anchor="w")

        request_frame = ttk.LabelFrame(right_frame, text="Add New Request (Real-time)", padding=10)
        request_frame.pack(fill=tk.X, pady=5)

        ttk.Label(request_frame, text="Source:").grid(row=0, column=0, padx=5, pady=5)
        self.source_spin = ttk.Spinbox(request_frame, from_=0, to=9, width=5, textvariable=self.source_var, state="readonly")
        self.source_spin.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(request_frame, text="Destination:").grid(row=0, column=2, padx=5, pady=5)
        self.dest_spin = ttk.Spinbox(request_frame, from_=0, to=9, width=5, textvariable=self.dest_var, state="readonly")
        self.dest_spin.grid(row=0, column=3, padx=5, pady=5)

        ttk.Label(request_frame, text="Count:").grid(row=1, column=0, padx=5, pady=5)
        self.count_spin = ttk.Spinbox(request_frame, from_=1, to=10, width=5, textvariable=self.count_var, state="readonly")
        self.count_spin.grid(row=1, column=1, padx=5, pady=5)

        btn_add = ttk.Button(request_frame, text="Submit Request", command=self.add_request_from_gui)
        btn_add.grid(row=2, column=0, columnspan=4, pady=10)

        log_frame = ttk.LabelFrame(right_frame, text="Event Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, state='disabled', font=("Courier", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)

        btn_stop = ttk.Button(right_frame, text="Stop Simulation", command=self.stop_simulation)
        btn_stop.pack(pady=5)

    def add_request_from_gui(self):
        src = self.source_var.get()
        dst = self.dest_var.get()
        count = self.count_var.get()
        if src == dst:
            self.log_message("Source and destination cannot be the same!")
            return
        if count > self.elevator.capacity:
            self.log_message(f"ERROR: Cannot request more than {self.elevator.capacity} passengers at once! Request rejected.")
            return
        if self.controller.add_request(src, dst, count):
            self.log_message(f"Request added: {count} passenger(s) from {src} to {dst}")
        else:
            self.log_message("Invalid request!")

    def log_message(self, msg):
        self.log_text.config(state='normal')
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')

    def update_graphics(self):
        floor = self.elevator.current_floor
        y_top = self.canvas_height - 20 - ((floor + 1) * self.floor_height)
        y_bot = self.canvas_height - 20 - (floor * self.floor_height)

        self.canvas.coords(self.elevator_rect, self.shaft_x1, y_top, self.shaft_x2, y_bot)
        self.canvas.coords(self.elevator_text, (self.shaft_x1 + self.shaft_x2)//2, (y_top + y_bot)//2)

        color = "green" if self.elevator.is_doors_open else "red"
        self.canvas.itemconfig(self.door_indicator, fill=color)

        dir_map = {1: "Up", -1: "Down", 0: "Stopped"}
        self.lbl_floor.config(text=f"Floor: {floor}")
        self.lbl_dir.config(text=f"Direction: {dir_map.get(self.elevator.direction, 'Unknown')}")
        self.lbl_passengers.config(text=f"Passengers: {len(self.elevator.passengers)}")
        self.lbl_capacity.config(text=f"Capacity: {len(self.elevator.passengers)}/{self.elevator.capacity}")

        self.lbl_avg_wait.config(text=f"Average Wait: {self.controller.get_average_wait_time()}s")
        self.lbl_max_wait.config(text=f"Max Wait: {self.controller.max_wait_time}s")
        self.lbl_served.config(text=f"Served Passengers: {self.controller.total_served}")

        # آپدیت خودکار Source به طبقه‌ی فعلی آسانسور
        self.source_var.set(floor)
        # اگر Destination با Source یکی شد، آن را تغییر بده
        if self.dest_var.get() == floor:
            new_dest = (floor + 1) % self.num_floors
            self.dest_var.set(new_dest)

        self.root.update_idletasks()

    def simulate_step(self):
        if not self.running:
            return

        events = self.controller.step()
        for event in events:
            self.log_message(event)

        self.update_graphics()

        self.root.after(1000, self.simulate_step)

    def stop_simulation(self):
        self.running = False
        self.log_message("Simulation stopped by user.")
        self.root.after(500, self.root.destroy)

if __name__ == "__main__":
    root = tk.Tk()
    app = ElevatorGUI(root)
    root.mainloop()