class Human:
    counter = 0  

    def __init__(self, name, age, height, weight):
        self.name = name
        self.age = age
        self.height = height
        self.weight = weight
        Human.counter += 1

    def get_age(self):
        return self.age

    def get_age_info(self):
        return "The " + self.name + "'s age is " + str(self.age)

    def die(self):
        Human.counter -= 1


class Student(Human):
    pass


#ali
ali = Human("Ali", 17, 570, 105)

print(ali.get_age())       
print(ali.get_age_info())   

print(Human.counter)        
ali.die()
print(Human.counter)
#erfan
erfan = Human("erfan", 18, 570, 105)

print(erfan.get_age())       
print(erfan.get_age_info())   

print(Human.counter)        
erfan.die()
print(Human.counter)          
