m = int(input("Pleas enter many number:"))
sum = 0
for i in range(m):
    num = int(input())
    sum += num
print("Sum is", sum)
