import tkinter as tk
from tkinter import ttk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import math

class TransferFunction:
    def __init__(self, K, order, zeta=None, omega_n=None, tau=None):
        self.K = K
        self.order = order
        self.zeta = zeta
        self.omega_n = omega_n
        self.tau = tau

    def get_step_response(self, t):
        if self.order == 1:
            if self.tau is None or self.tau == 0:
                return np.full_like(t, self.K)
            return self.K * (1 - np.exp(-t / self.tau))
        else:
            if self.zeta is None or self.omega_n is None:
                return np.zeros_like(t)
            wn = self.omega_n
            z = self.zeta
            if z < 1:
                wd = wn * np.sqrt(1 - z**2)
                phi = np.arccos(z)
                return self.K * (1 - (np.exp(-z*wn*t) / np.sqrt(1 - z**2)) * np.sin(wd*t + phi))
            elif z == 1:
                return self.K * (1 - np.exp(-wn*t) * (1 + wn*t))
            else:
                p1 = -z*wn + wn*np.sqrt(z**2 - 1)
                p2 = -z*wn - wn*np.sqrt(z**2 - 1)
                A = p2 / (p1 - p2)
                B = -p1 / (p1 - p2)
                return self.K * (1 + A*np.exp(p1*t) + B*np.exp(p2*t))

class StepResponse:
    def __init__(self, tf, t_max=10, num_points=1000):
        self.tf = tf
        self.t = np.linspace(0, t_max, num_points)
        self.response = tf.get_step_response(self.t)
        self.steady_state = self.response[-1] if len(self.response) > 0 else 0

    def get_settling_time(self, tolerance=0.02):
        if len(self.response) == 0:
            return 0
        steady = self.steady_state
        tol = tolerance * steady
        indices = np.where(np.abs(self.response - steady) > tol)[0]
        if len(indices) == 0:
            return 0
        settle_index = indices[-1] + 1
        if settle_index >= len(self.t):
            return self.t[-1]
        return self.t[settle_index]

    def get_overshoot(self):
        if len(self.response) == 0:
            return 0
        steady = self.steady_state
        if steady == 0:
            return 0
        max_val = np.max(self.response)
        overshoot = (max_val - steady) / steady * 100
        return max(0, overshoot)

    def get_rise_time(self, low=0.1, high=0.9):
        if len(self.response) == 0:
            return 0
        steady = self.steady_state
        if steady == 0:
            return 0
        low_val = low * steady
        high_val = high * steady
        low_idx = None
        high_idx = None
        for i, val in enumerate(self.response):
            if low_idx is None and val >= low_val:
                low_idx = i
            if high_idx is None and val >= high_val:
                high_idx = i
            if low_idx is not None and high_idx is not None:
                break
        if low_idx is None or high_idx is None:
            return 0
        return self.t[high_idx] - self.t[low_idx]

class Analyzer:
    def __init__(self, step_response):
        self.step = step_response
        self.settling_time = step_response.get_settling_time()
        self.overshoot = step_response.get_overshoot()
        self.rise_time = step_response.get_rise_time()

class Plotter:
    def __init__(self, fig, ax):
        self.fig = fig
        self.ax = ax

    def plot(self, t, response, title="Step Response"):
        self.ax.clear()
        self.ax.plot(t, response, 'b-', linewidth=2)
        self.ax.grid(True, linestyle='--', alpha=0.7)
        self.ax.set_xlabel('Time (s)')
        self.ax.set_ylabel('Output')
        self.ax.set_title(title)
        self.fig.tight_layout()

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("System Response Analysis Tool")
        self.root.geometry("900x650")
        self.root.resizable(False, False)

        self.order_var = tk.StringVar(value="2")
        self.K_var = tk.DoubleVar(value=1.0)
        self.zeta_var = tk.DoubleVar(value=0.5)
        self.omega_n_var = tk.DoubleVar(value=2.0)
        self.tau_var = tk.DoubleVar(value=1.0)

        self.setup_ui()
        self.update_fields()
        self.calculate()

    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.fig, self.ax = plt.subplots(figsize=(6, 4))
        self.canvas = FigureCanvasTkAgg(self.fig, master=left_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        right_frame = ttk.Frame(main_frame, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(right_frame, text="System Parameters", font=("Arial", 14, "bold")).pack(pady=5)

        order_frame = ttk.LabelFrame(right_frame, text="Order")
        order_frame.pack(fill=tk.X, pady=5)
        ttk.Radiobutton(order_frame, text="First Order", variable=self.order_var, value="1", command=self.update_fields).pack(anchor="w")
        ttk.Radiobutton(order_frame, text="Second Order", variable=self.order_var, value="2", command=self.update_fields).pack(anchor="w")

        param_frame = ttk.LabelFrame(right_frame, text="Parameters")
        param_frame.pack(fill=tk.X, pady=5)

        ttk.Label(param_frame, text="K (Gain):").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.K_entry = ttk.Entry(param_frame, width=10, textvariable=self.K_var)
        self.K_entry.grid(row=0, column=1, padx=5, pady=2)

        self.zeta_label = ttk.Label(param_frame, text="ζ (Damping):")
        self.zeta_label.grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.zeta_entry = ttk.Entry(param_frame, width=10, textvariable=self.zeta_var)
        self.zeta_entry.grid(row=1, column=1, padx=5, pady=2)

        self.wn_label = ttk.Label(param_frame, text="ωn (Natural):")
        self.wn_label.grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.wn_entry = ttk.Entry(param_frame, width=10, textvariable=self.omega_n_var)
        self.wn_entry.grid(row=2, column=1, padx=5, pady=2)

        self.tau_label = ttk.Label(param_frame, text="τ (Time const):")
        self.tau_label.grid(row=3, column=0, padx=5, pady=2, sticky="w")
        self.tau_entry = ttk.Entry(param_frame, width=10, textvariable=self.tau_var)
        self.tau_entry.grid(row=3, column=1, padx=5, pady=2)

        ttk.Button(param_frame, text="Calculate", command=self.calculate).grid(row=4, column=0, columnspan=2, pady=10)

        results_frame = ttk.LabelFrame(right_frame, text="Results")
        results_frame.pack(fill=tk.X, pady=5)

        self.lbl_settling = ttk.Label(results_frame, text="Settling Time: -- s")
        self.lbl_settling.pack(anchor="w")
        self.lbl_overshoot = ttk.Label(results_frame, text="Overshoot: -- %")
        self.lbl_overshoot.pack(anchor="w")
        self.lbl_rise = ttk.Label(results_frame, text="Rise Time: -- s")
        self.lbl_rise.pack(anchor="w")

    def update_fields(self):
        if self.order_var.get() == "1":
            self.zeta_label.grid_remove()
            self.zeta_entry.grid_remove()
            self.wn_label.grid_remove()
            self.wn_entry.grid_remove()
            self.tau_label.grid()
            self.tau_entry.grid()
        else:
            self.zeta_label.grid()
            self.zeta_entry.grid()
            self.wn_label.grid()
            self.wn_entry.grid()
            self.tau_label.grid_remove()
            self.tau_entry.grid_remove()

    def calculate(self):
        try:
            K = self.K_var.get()
            order = int(self.order_var.get())
            if order == 1:
                tau = self.tau_var.get()
                if tau <= 0:
                    return
                tf = TransferFunction(K, order, tau=tau)
                step_resp = StepResponse(tf, t_max=10, num_points=1000)
                analyzer = Analyzer(step_resp)
                self.lbl_settling.config(text=f"Settling Time: {analyzer.settling_time:.3f} s")
                self.lbl_overshoot.config(text=f"Overshoot: {analyzer.overshoot:.2f} %")
                self.lbl_rise.config(text=f"Rise Time: {analyzer.rise_time:.3f} s")
                plotter = Plotter(self.fig, self.ax)
                plotter.plot(step_resp.t, step_resp.response, title="First Order Step Response")
                self.canvas.draw()
            else:
                zeta = self.zeta_var.get()
                wn = self.omega_n_var.get()
                if zeta <= 0 or wn <= 0:
                    return
                tf = TransferFunction(K, order, zeta=zeta, omega_n=wn)
                step_resp = StepResponse(tf, t_max=10, num_points=1000)
                analyzer = Analyzer(step_resp)
                self.lbl_settling.config(text=f"Settling Time: {analyzer.settling_time:.3f} s")
                self.lbl_overshoot.config(text=f"Overshoot: {analyzer.overshoot:.2f} %")
                self.lbl_rise.config(text=f"Rise Time: {analyzer.rise_time:.3f} s")
                plotter = Plotter(self.fig, self.ax)
                plotter.plot(step_resp.t, step_resp.response, title="Second Order Step Response")
                self.canvas.draw()
        except Exception as e:
            pass

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()