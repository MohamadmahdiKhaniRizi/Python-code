import tkinter as tk
from tkinter import ttk
import random
import threading
import time
from collections import deque

class Car:
    def __init__(self, car_id, direction):
        self.id = car_id
        self.direction = direction
        self.position = 0
        self.color = random.choice(["red", "blue", "green", "yellow", "orange", "purple", "cyan"])

    def __repr__(self):
        return f"Car({self.id}, {self.direction})"

class TrafficLight:
    def __init__(self, direction):
        self.direction = direction
        self.state = "RED"

    def set_state(self, state):
        self.state = state

    def get_color(self):
        return self.state

class Lane:
    def __init__(self, direction):
        self.direction = direction
        self.queue = deque()
        self.traffic_light = TrafficLight(direction)

    def add_car(self, car):
        self.queue.append(car)

    def remove_car(self):
        if self.queue:
            return self.queue.popleft()
        return None

    def get_queue_length(self):
        return len(self.queue)

class Intersection:
    def __init__(self):
        self.lanes = {
            "N": Lane("N"),
            "S": Lane("S"),
            "E": Lane("E"),
            "W": Lane("W")
        }
        self.car_counter = 0

    def add_car(self, direction):
        if direction in self.lanes:
            car = Car(self.car_counter, direction)
            self.car_counter += 1
            self.lanes[direction].add_car(car)
            return True
        return False

    def remove_car_from_lane(self, direction):
        if direction in self.lanes:
            return self.lanes[direction].remove_car()
        return None

    def get_queue_lengths(self):
        return {dir: lane.get_queue_length() for dir, lane in self.lanes.items()}

class AdaptiveController:
    def __init__(self, intersection, gui_callback=None, car_exit_callback=None):
        self.intersection = intersection
        self.gui_callback = gui_callback
        self.car_exit_callback = car_exit_callback
        self.current_phase = 0
        self.base_green_time = 10
        self.yellow_time = 3
        self.is_running = False
        self.adaptive_mode = True
        self.exit_rate = 0.5
        self.custom_green_time = 10
        self.custom_yellow_time = 3

    def start(self):
        self.is_running = True
        self._run_phase()

    def stop(self):
        self.is_running = False

    def set_green_time(self, seconds):
        self.custom_green_time = max(3, min(30, seconds))
        if not self.adaptive_mode:
            self.base_green_time = self.custom_green_time

    def set_yellow_time(self, seconds):
        self.custom_yellow_time = max(1, min(5, seconds))
        self.yellow_time = self.custom_yellow_time

    def set_adaptive_mode(self, enable):
        self.adaptive_mode = enable
        if not enable:
            self.base_green_time = self.custom_green_time

    def _run_phase(self):
        if not self.is_running:
            return

        if self.current_phase == 0:
            self._set_lights("N", "GREEN")
            self._set_lights("S", "GREEN")
            self._set_lights("E", "RED")
            self._set_lights("W", "RED")
            active_dirs = ["N", "S"]
        else:
            self._set_lights("E", "GREEN")
            self._set_lights("W", "GREEN")
            self._set_lights("N", "RED")
            self._set_lights("S", "RED")
            active_dirs = ["E", "W"]

        if self.gui_callback:
            self.gui_callback()

        if self.adaptive_mode:
            green_time = self._calculate_adaptive_green_time()
        else:
            green_time = self.base_green_time

        start_time = time.time()
        while time.time() - start_time < green_time:
            if not self.is_running:
                return
            for d in active_dirs:
                if random.random() < self.exit_rate:
                    removed = self.intersection.remove_car_from_lane(d)
                    if removed and self.car_exit_callback:
                        self.car_exit_callback(d, removed)
            if self.gui_callback:
                self.gui_callback()
            time.sleep(1)

        if not self.is_running:
            return

        self._set_yellow_phase()
        time.sleep(self.yellow_time)

        if not self.is_running:
            return

        self.current_phase = 1 - self.current_phase
        self._run_phase()

    def _set_lights(self, direction, state):
        self.intersection.lanes[direction].traffic_light.set_state(state)

    def _set_yellow_phase(self):
        if self.current_phase == 0:
            self._set_lights("N", "YELLOW")
            self._set_lights("S", "YELLOW")
        else:
            self._set_lights("E", "YELLOW")
            self._set_lights("W", "YELLOW")
        if self.gui_callback:
            self.gui_callback()

    def _calculate_adaptive_green_time(self):
        queues = self.intersection.get_queue_lengths()
        if self.current_phase == 0:
            length = queues["N"] + queues["S"]
            other = queues["E"] + queues["W"]
        else:
            length = queues["E"] + queues["W"]
            other = queues["N"] + queues["S"]
        total = length + other
        if total == 0:
            return self.base_green_time
        ratio = length / total
        adaptive_time = max(3, int(ratio * 30))
        return min(adaptive_time, 30)

    def toggle_adaptive(self, enable):
        self.adaptive_mode = enable
        if not enable:
            self.base_green_time = self.custom_green_time

    def set_exit_rate(self, rate):
        self.exit_rate = rate

class TrafficSimulatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Intelligent Intersection Simulator")
        self.root.geometry("900x760")
        self.root.resizable(False, False)

        self.intersection = Intersection()
        self.controller = AdaptiveController(self.intersection, self.update_gui, self.on_car_exit)
        self.running = False

        self.canvas_width = 600
        self.canvas_height = 600
        self.cell_size = 120
        self.offset = 30

        self.setup_ui()

    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(left_frame, width=self.canvas_width, height=self.canvas_height, bg="#2d2d2d")
        self.canvas.pack()

        self.draw_intersection()

        right_frame = ttk.Frame(main_frame, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(right_frame, text="Traffic Control", font=("Arial", 14, "bold")).pack(pady=5)

        self.status_var = tk.StringVar(value="Status: Stopped")
        ttk.Label(right_frame, textvariable=self.status_var).pack(anchor="w")

        ttk.Label(right_frame, text="Queue Lengths:", font=("Arial", 11)).pack(anchor="w", pady=(10,0))
        self.queue_labels = {}
        for dir in ["N", "S", "E", "W"]:
            lbl = ttk.Label(right_frame, text=f"{dir}: 0")
            lbl.pack(anchor="w")
            self.queue_labels[dir] = lbl

        ttk.Label(right_frame, text="Lights:", font=("Arial", 11)).pack(anchor="w", pady=(10,0))
        self.light_labels = {}
        for dir in ["N", "S", "E", "W"]:
            lbl = ttk.Label(right_frame, text=f"{dir}: RED")
            lbl.pack(anchor="w")
            self.light_labels[dir] = lbl

        ttk.Separator(right_frame, orient='horizontal').pack(fill='x', pady=10)

        # Control frame
        control_frame = ttk.LabelFrame(right_frame, text="Control")
        control_frame.pack(fill=tk.X, pady=5)

        self.adaptive_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(control_frame, text="Adaptive Timing", variable=self.adaptive_var, command=self.toggle_adaptive).pack(anchor="w")

        # Green time control
        time_frame = ttk.Frame(control_frame)
        time_frame.pack(fill=tk.X, pady=2)
        ttk.Label(time_frame, text="Green Time:").pack(side=tk.LEFT)
        self.green_var = tk.IntVar(value=10)
        green_spin = ttk.Spinbox(time_frame, from_=3, to=30, width=5, textvariable=self.green_var, command=self.update_timing)
        green_spin.pack(side=tk.LEFT, padx=5)
        ttk.Label(time_frame, text="sec").pack(side=tk.LEFT)

        time_frame2 = ttk.Frame(control_frame)
        time_frame2.pack(fill=tk.X, pady=2)
        ttk.Label(time_frame2, text="Yellow Time:").pack(side=tk.LEFT)
        self.yellow_var = tk.IntVar(value=3)
        yellow_spin = ttk.Spinbox(time_frame2, from_=1, to=5, width=5, textvariable=self.yellow_var, command=self.update_timing)
        yellow_spin.pack(side=tk.LEFT, padx=5)
        ttk.Label(time_frame2, text="sec").pack(side=tk.LEFT)

        btn_start = ttk.Button(control_frame, text="Start Simulation", command=self.start_simulation)
        btn_start.pack(fill=tk.X, pady=2)

        btn_stop = ttk.Button(control_frame, text="Stop Simulation", command=self.stop_simulation)
        btn_stop.pack(fill=tk.X, pady=2)

        btn_add_car = ttk.Button(control_frame, text="Add Random Car", command=self.add_random_car)
        btn_add_car.pack(fill=tk.X, pady=2)

        btn_add_specific = ttk.Button(control_frame, text="Add Car to Specific Lane", command=self.add_specific_car)
        btn_add_specific.pack(fill=tk.X, pady=2)

        btn_remove_car = ttk.Button(control_frame, text="Remove a Car from Lane", command=self.remove_car_from_lane)
        btn_remove_car.pack(fill=tk.X, pady=2)

        self.auto_add_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(control_frame, text="Auto-add Cars", variable=self.auto_add_var, command=self.toggle_auto_add).pack(anchor="w")

        ttk.Label(right_frame, text="Event Log", font=("Arial", 11)).pack(anchor="w", pady=(10,0))
        self.log_text = tk.Text(right_frame, height=8, width=25, state='disabled')
        self.log_text.pack(fill=tk.BOTH, expand=True, pady=5)

        self.auto_add_active = False
        self.auto_add_thread = None
        self.car_objects = {}

    def draw_intersection(self):
        self.canvas.delete("all")
        W = self.canvas_width
        H = self.canvas_height
        c = self.cell_size
        off = self.offset

        self.canvas.create_rectangle(0, 0, W, H, fill="#2d5a27")
        self.canvas.create_rectangle(off, off+c, off+4*c, off+3*c, fill="#444", outline="#555")
        self.canvas.create_rectangle(off+c, off, off+3*c, off+4*c, fill="#444", outline="#555")
        self.canvas.create_rectangle(off+c, off+c, off+3*c, off+3*c, fill="#555", outline="#777")

        for i in range(1, 4):
            x = off + i*c
            self.canvas.create_line(x, off+c+10, x, off+3*c-10, fill="#fff", dash=(5,5), width=2)
        for i in range(1, 4):
            y = off + i*c
            self.canvas.create_line(off+c+10, y, off+3*c-10, y, fill="#fff", dash=(5,5), width=2)

        self.canvas.create_text(off+2*c, off+20, text="NORTH", fill="white", font=("Arial", 10, "bold"))
        self.canvas.create_text(off+2*c, off+4*c-20, text="SOUTH", fill="white", font=("Arial", 10, "bold"))
        self.canvas.create_text(off+4*c-20, off+2*c, text="EAST", fill="white", font=("Arial", 10, "bold"))
        self.canvas.create_text(off+20, off+2*c, text="WEST", fill="white", font=("Arial", 10, "bold"))

        arrow_coords = {
            "N": (off+2*c, off+c+15, off+2*c, off+c-15, off+2*c-10, off+c, off+2*c+10, off+c),
            "S": (off+2*c, off+3*c-15, off+2*c, off+3*c+15, off+2*c-10, off+3*c, off+2*c+10, off+3*c),
            "E": (off+3*c-15, off+2*c, off+3*c+15, off+2*c, off+3*c, off+2*c-10, off+3*c, off+2*c+10),
            "W": (off+c+15, off+2*c, off+c-15, off+2*c, off+c, off+2*c-10, off+c, off+2*c+10)
        }
        for d, coords in arrow_coords.items():
            self.canvas.create_polygon(coords, fill="#aaa", outline="#ccc")

        light_pos = {
            "N": (off+2*c-20, off+c+30),
            "S": (off+2*c+20, off+3*c-30),
            "E": (off+3*c-30, off+2*c+20),
            "W": (off+c+30, off+2*c-20)
        }
        self.light_ids = {}
        for d, pos in light_pos.items():
            rect = self.canvas.create_rectangle(pos[0]-15, pos[1]-30, pos[0]+15, pos[1]+30, fill="#111", outline="#666")
            r = self.canvas.create_oval(pos[0]-10, pos[1]-25, pos[0]+10, pos[1]-5, fill="red", outline="red")
            y = self.canvas.create_oval(pos[0]-10, pos[1]-10, pos[0]+10, pos[1]+10, fill="#333", outline="#444")
            g = self.canvas.create_oval(pos[0]-10, pos[1]+5, pos[0]+10, pos[1]+25, fill="#333", outline="#444")
            self.light_ids[d] = (r, y, g, rect)

        self.entry_points = {
            "N": (off+2*c, off+c),
            "S": (off+2*c, off+3*c),
            "E": (off+3*c, off+2*c),
            "W": (off+c, off+2*c)
        }
        self.car_objects = {}

    def update_gui(self):
        queues = self.intersection.get_queue_lengths()
        for d, lbl in self.queue_labels.items():
            lbl.config(text=f"{d}: {queues[d]}")

        for d in ["N", "S", "E", "W"]:
            state = self.intersection.lanes[d].traffic_light.get_color()
            self.light_labels[d].config(text=f"{d}: {state}")
            r, y, g, rect = self.light_ids[d]
            if state == "RED":
                self.canvas.itemconfig(r, fill="red", outline="red")
                self.canvas.itemconfig(y, fill="#333", outline="#444")
                self.canvas.itemconfig(g, fill="#333", outline="#444")
            elif state == "YELLOW":
                self.canvas.itemconfig(r, fill="#333", outline="#444")
                self.canvas.itemconfig(y, fill="yellow", outline="yellow")
                self.canvas.itemconfig(g, fill="#333", outline="#444")
            elif state == "GREEN":
                self.canvas.itemconfig(r, fill="#333", outline="#444")
                self.canvas.itemconfig(y, fill="#333", outline="#444")
                self.canvas.itemconfig(g, fill="green", outline="green")

        self.draw_cars()

    def draw_cars(self):
        for cid in list(self.car_objects.keys()):
            self.canvas.delete(cid)
        self.car_objects.clear()

        lane_positions = {
            "N": (self.offset+2*self.cell_size, self.offset+self.cell_size),
            "S": (self.offset+2*self.cell_size, self.offset+3*self.cell_size),
            "E": (self.offset+3*self.cell_size, self.offset+2*self.cell_size),
            "W": (self.offset+self.cell_size, self.offset+2*self.cell_size)
        }
        for d, lane in self.intersection.lanes.items():
            cars = list(lane.queue)
            max_display = 8
            for i, car in enumerate(cars):
                if i >= max_display:
                    break
                x, y = lane_positions[d]
                if d == "N":
                    y = y + i * 18 + 10
                elif d == "S":
                    y = y - i * 18 - 10
                elif d == "E":
                    x = x - i * 18 - 10
                elif d == "W":
                    x = x + i * 18 + 10
                car_id = self.canvas.create_rectangle(x-10, y-6, x+10, y+6, fill=car.color, outline="black", width=1)
                self.car_objects[car_id] = car

    def on_car_exit(self, direction, car):
        self.log_message(f"Car {car.id} exited from {direction}")
        self.update_gui()

    def update_timing(self):
        green = self.green_var.get()
        yellow = self.yellow_var.get()
        self.controller.set_green_time(green)
        self.controller.set_yellow_time(yellow)
        self.log_message(f"Timing updated: Green={green}s, Yellow={yellow}s")

    def start_simulation(self):
        if not self.running:
            self.running = True
            self.status_var.set("Status: Running")
            self.log_message("Simulation started.")
            threading.Thread(target=self.controller.start, daemon=True).start()

    def stop_simulation(self):
        if self.running:
            self.running = False
            self.controller.stop()
            self.status_var.set("Status: Stopped")
            self.log_message("Simulation stopped.")
            self.update_gui()

    def add_random_car(self):
        dirs = ["N", "S", "E", "W"]
        d = random.choice(dirs)
        if self.intersection.add_car(d):
            self.log_message(f"Added car to {d}")
            self.update_gui()
        else:
            self.log_message("Failed to add car.")

    def add_specific_car(self):
        top = tk.Toplevel(self.root)
        top.title("Add Car")
        ttk.Label(top, text="Choose direction:").pack(pady=5)
        var = tk.StringVar(value="N")
        for d in ["N", "S", "E", "W"]:
            ttk.Radiobutton(top, text=d, variable=var, value=d).pack(anchor="w")
        def submit():
            d = var.get()
            if self.intersection.add_car(d):
                self.log_message(f"Added car to {d}")
                self.update_gui()
            else:
                self.log_message("Failed to add car.")
            top.destroy()
        ttk.Button(top, text="Add", command=submit).pack(pady=5)

    def remove_car_from_lane(self):
        top = tk.Toplevel(self.root)
        top.title("Remove Car")
        ttk.Label(top, text="Choose lane:").pack(pady=5)
        var = tk.StringVar(value="N")
        for d in ["N", "S", "E", "W"]:
            ttk.Radiobutton(top, text=d, variable=var, value=d).pack(anchor="w")
        def submit():
            d = var.get()
            removed = self.intersection.remove_car_from_lane(d)
            if removed:
                self.log_message(f"Removed car {removed.id} from {d}")
                self.update_gui()
            else:
                self.log_message(f"No car in {d} lane.")
            top.destroy()
        ttk.Button(top, text="Remove", command=submit).pack(pady=5)

    def toggle_auto_add(self):
        if self.auto_add_var.get():
            self.auto_add_active = True
            self.log_message("Auto-add enabled.")
            if self.auto_add_thread is None or not self.auto_add_thread.is_alive():
                self.auto_add_thread = threading.Thread(target=self.auto_add_loop, daemon=True)
                self.auto_add_thread.start()
        else:
            self.auto_add_active = False
            self.log_message("Auto-add disabled.")

    def auto_add_loop(self):
        while self.auto_add_active and self.running:
            time.sleep(random.uniform(0.5, 2))
            if self.auto_add_active:
                self.root.after(0, self.add_random_car)

    def toggle_adaptive(self):
        enable = self.adaptive_var.get()
        self.controller.toggle_adaptive(enable)
        self.log_message(f"Adaptive mode {'enabled' if enable else 'disabled'}")
        if not enable:
            self.controller.set_green_time(self.green_var.get())
            self.controller.set_yellow_time(self.yellow_var.get())

    def log_message(self, msg):
        self.log_text.config(state='normal')
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')

if __name__ == "__main__":
    root = tk.Tk()
    app = TrafficSimulatorGUI(root)
    root.mainloop()