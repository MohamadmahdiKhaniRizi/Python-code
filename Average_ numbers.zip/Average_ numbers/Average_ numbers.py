sum = 0.0
count = 0

print("Enter numbers:")
print("double Enter to count!!")

while True:
    value = input(f"Number {count + 1}: ")

    if value == "":
        break

    sum += float(value)
    count += 1

if count > 0:
    avg = sum / count
    print(f"Average is: {avg:.2f}")
else:
    print("Erorr: No numbers entered.")
