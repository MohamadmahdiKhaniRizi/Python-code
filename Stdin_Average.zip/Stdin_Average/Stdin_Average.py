import sys
sum = 0.0
count = 0
for line in sys.stdin:
    try:
        sum =sum + float(line.strip())
        count =count + 1
    except ValueError:
        continue

if count > 0:
    print(f"Average: {sum / count}")
else:
    print("Not valid numbers!!")
