import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
import time
import random

class Tank:
    def __init__(self, capacity=50, initial_level=0):
        self.capacity = capacity
        self.level = initial_level
        self.max_level = capacity

    def update(self, inflow, outflow, dt):
        self.level += (inflow - outflow) * dt
        if self.level < 0:
            self.level = 0
        elif self.level > self.capacity:
            self.level = self.capacity
        return self.level

    def get_level(self):
        return self.level

    def get_percent(self):
        return (self.level / self.capacity) * 100

class Pump:
    def __init__(self, max_flow=10):
        self.max_flow = max_flow
        self.is_on = False
        self.flow_rate = 0

    def set_state(self, state):
        self.is_on = state
        self.flow_rate = self.max_flow if state else 0

    def set_flow(self, flow):
        self.flow_rate = max(0, min(flow, self.max_flow))
        self.is_on = (self.flow_rate > 0)

    def get_flow(self):
        return self.flow_rate

class Sensor:
    def __init__(self, tank, noise=0.1):
        self.tank = tank
        self.noise = noise

    def read_level(self):
        return self.tank.get_level() + random.uniform(-self.noise, self.noise)

class Controller:
    def __init__(self, setpoint=25, mode="PID", kp=2.0, ki=0.5, kd=0.1, dt=0.1):
        self.setpoint = setpoint
        self.mode = mode  # "ONOFF" or "PID"
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.dt = dt
        self.integral = 0
        self.prev_error = 0
        self.output_min = 0
        self.output_max = 10  # max pump flow

    def set_setpoint(self, sp):
        self.setpoint = sp

    def set_mode(self, mode):
        self.mode = mode

    def compute(self, measured_level):
        error = self.setpoint - measured_level
        if self.mode == "ONOFF":
            if error > 0.5:
                output = self.output_max
            elif error < -0.5:
                output = 0
            else:
                output = self.output_max / 2  # keep near setpoint
            return output
        elif self.mode == "PID":
            self.integral += error * self.dt
            derivative = (error - self.prev_error) / self.dt
            output = self.kp * error + self.ki * self.integral + self.kd * derivative
            self.prev_error = error
            output = max(self.output_min, min(output, self.output_max))
            return output
        else:
            return 0

class Simulation:
    def __init__(self, tank, pump, sensor, controller):
        self.tank = tank
        self.pump = pump
        self.sensor = sensor
        self.controller = controller
        self.time_data = []
        self.level_data = []
        self.setpoint_data = []
        self.inflow_data = []
        self.outflow_data = []
        self.running = False
        self.paused = False
        self.dt = 0.1
        self.sim_time = 0

    def step(self):
        measured = self.sensor.read_level()
        control_signal = self.controller.compute(measured)
        self.pump.set_flow(control_signal)
        inflow = self.pump.get_flow()
        outflow = random.uniform(1.0, 3.0)  # variable outflow
        self.tank.update(inflow, outflow, self.dt)
        self.sim_time += self.dt
        self.time_data.append(self.sim_time)
        self.level_data.append(self.tank.get_level())
        self.setpoint_data.append(self.controller.setpoint)
        self.inflow_data.append(inflow)
        self.outflow_data.append(outflow)
        return self.tank.get_level(), inflow, outflow

    def run(self, duration):
        self.running = True
        while self.running and self.sim_time < duration:
            if not self.paused:
                self.step()
            time.sleep(self.dt)

    def stop(self):
        self.running = False

    def reset(self):
        self.tank.level = 0
        self.sim_time = 0
        self.time_data.clear()
        self.level_data.clear()
        self.setpoint_data.clear()
        self.inflow_data.clear()
        self.outflow_data.clear()
        self.pump.set_state(False)
        self.controller.integral = 0
        self.controller.prev_error = 0

class WaterTankGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Water Tank Level Control Simulation")
        self.root.geometry("1100x750")
        self.root.resizable(False, False)

        self.tank = Tank(capacity=50)
        self.pump = Pump(max_flow=10)
        self.sensor = Sensor(self.tank, noise=0.2)
        self.controller = Controller(setpoint=25, mode="PID")
        self.sim = Simulation(self.tank, self.pump, self.sensor, self.controller)

        self.running = False
        self.thread = None

        self.setup_ui()

    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Left panel: Tank visualization and controls
        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Canvas for tank
        self.canvas = tk.Canvas(left_frame, width=300, height=400, bg="white")
        self.canvas.pack(pady=10)

        # Matplotlib figure for real-time plot
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(5, 4))
        self.fig.subplots_adjust(hspace=0.4)
        self.ax1.set_title("Water Level vs Time")
        self.ax1.set_xlabel("Time (s)")
        self.ax1.set_ylabel("Level (L)")
        self.ax1.grid(True)
        self.ax2.set_title("Control Signal & Outflow")
        self.ax2.set_xlabel("Time (s)")
        self.ax2.set_ylabel("Flow (L/s)")
        self.ax2.grid(True)

        self.canvas_plot = FigureCanvasTkAgg(self.fig, master=left_frame)
        self.canvas_plot.get_tk_widget().pack()

        # Right panel: Controls and stats
        right_frame = ttk.Frame(main_frame, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(right_frame, text="Tank Control", font=("Arial", 14, "bold")).pack(pady=5)

        # Setpoint
        sp_frame = ttk.Frame(right_frame)
        sp_frame.pack(fill=tk.X, pady=2)
        ttk.Label(sp_frame, text="Setpoint (L):").pack(side=tk.LEFT)
        self.sp_var = tk.DoubleVar(value=25)
        sp_spin = ttk.Spinbox(sp_frame, from_=5, to=45, width=6, textvariable=self.sp_var, command=self.update_setpoint)
        sp_spin.pack(side=tk.LEFT, padx=5)

        # Control mode
        mode_frame = ttk.LabelFrame(right_frame, text="Control Mode")
        mode_frame.pack(fill=tk.X, pady=5)
        self.mode_var = tk.StringVar(value="PID")
        ttk.Radiobutton(mode_frame, text="PID", variable=self.mode_var, value="PID", command=self.update_mode).pack(anchor="w")
        ttk.Radiobutton(mode_frame, text="On-Off", variable=self.mode_var, value="ONOFF", command=self.update_mode).pack(anchor="w")

        # PID parameters (if needed later)
        param_frame = ttk.LabelFrame(right_frame, text="PID Parameters")
        param_frame.pack(fill=tk.X, pady=5)
        ttk.Label(param_frame, text="Kp:").grid(row=0, column=0, padx=2)
        self.kp_var = tk.DoubleVar(value=2.0)
        ttk.Entry(param_frame, width=6, textvariable=self.kp_var).grid(row=0, column=1)
        ttk.Label(param_frame, text="Ki:").grid(row=1, column=0, padx=2)
        self.ki_var = tk.DoubleVar(value=0.5)
        ttk.Entry(param_frame, width=6, textvariable=self.ki_var).grid(row=1, column=1)
        ttk.Label(param_frame, text="Kd:").grid(row=2, column=0, padx=2)
        self.kd_var = tk.DoubleVar(value=0.1)
        ttk.Entry(param_frame, width=6, textvariable=self.kd_var).grid(row=2, column=1)
        ttk.Button(param_frame, text="Update PID", command=self.update_pid).grid(row=3, column=0, columnspan=2, pady=5)

        # Simulation controls
        ctrl_frame = ttk.Frame(right_frame)
        ctrl_frame.pack(fill=tk.X, pady=10)
        self.btn_start = ttk.Button(ctrl_frame, text="Start", command=self.start_sim)
        self.btn_start.pack(side=tk.LEFT, padx=5)
        self.btn_pause = ttk.Button(ctrl_frame, text="Pause", command=self.pause_sim, state=tk.DISABLED)
        self.btn_pause.pack(side=tk.LEFT, padx=5)
        self.btn_stop = ttk.Button(ctrl_frame, text="Stop", command=self.stop_sim, state=tk.DISABLED)
        self.btn_stop.pack(side=tk.LEFT, padx=5)
        self.btn_reset = ttk.Button(ctrl_frame, text="Reset", command=self.reset_sim)
        self.btn_reset.pack(side=tk.LEFT, padx=5)

        # Status and statistics
        status_frame = ttk.LabelFrame(right_frame, text="Status")
        status_frame.pack(fill=tk.X, pady=5)
        self.lbl_level = ttk.Label(status_frame, text="Level: 0.0 L")
        self.lbl_level.pack(anchor="w")
        self.lbl_inflow = ttk.Label(status_frame, text="Inflow: 0.0 L/s")
        self.lbl_inflow.pack(anchor="w")
        self.lbl_outflow = ttk.Label(status_frame, text="Outflow: 0.0 L/s")
        self.lbl_outflow.pack(anchor="w")
        self.lbl_error = ttk.Label(status_frame, text="Error: 0.0 L")
        self.lbl_error.pack(anchor="w")
        self.lbl_mode = ttk.Label(status_frame, text="Mode: PID")
        self.lbl_mode.pack(anchor="w")

        # Plot update interval
        self.update_plot()

    def draw_tank(self, level):
        self.canvas.delete("all")
        # Tank outline
        x0, y0, x1, y1 = 50, 50, 250, 350
        self.canvas.create_rectangle(x0, y0, x1, y1, outline="black", width=2)
        # Water
        water_height = (level / self.tank.capacity) * (y1 - y0)
        y_water = y1 - water_height
        self.canvas.create_rectangle(x0+2, y_water, x1-2, y1-2, fill="blue", outline="blue")
        # Markings
        for i in range(0, 11):
            y = y0 + i * (y1 - y0) / 10
            self.canvas.create_line(x0-5, y, x0, y, fill="gray")
            self.canvas.create_text(x0-10, y, text=str(int(i*5)), font=("Arial", 8))
        # Level text
        self.canvas.create_text(x0+100, y0-10, text=f"{level:.1f} L", font=("Arial", 12, "bold"))

    def update_plot(self):
        if self.sim.time_data:
            self.ax1.clear()
            self.ax1.plot(self.sim.time_data, self.sim.level_data, label="Level")
            self.ax1.plot(self.sim.time_data, self.sim.setpoint_data, 'r--', label="Setpoint")
            self.ax1.set_title("Water Level vs Time")
            self.ax1.set_xlabel("Time (s)")
            self.ax1.set_ylabel("Level (L)")
            self.ax1.legend()
            self.ax1.grid(True)

            self.ax2.clear()
            self.ax2.plot(self.sim.time_data, self.sim.inflow_data, label="Inflow (Pump)")
            self.ax2.plot(self.sim.time_data, self.sim.outflow_data, label="Outflow (Drain)")
            self.ax2.set_title("Flow Rates")
            self.ax2.set_xlabel("Time (s)")
            self.ax2.set_ylabel("Flow (L/s)")
            self.ax2.legend()
            self.ax2.grid(True)

            self.canvas_plot.draw()

        self.draw_tank(self.tank.get_level())
        self.update_status()
        if self.running:
            self.root.after(500, self.update_plot)
        else:
            self.root.after(1000, self.update_plot)

    def update_status(self):
        level = self.tank.get_level()
        error = self.controller.setpoint - level
        self.lbl_level.config(text=f"Level: {level:.2f} L")
        self.lbl_inflow.config(text=f"Inflow: {self.pump.get_flow():.2f} L/s")
        self.lbl_outflow.config(text=f"Outflow: {self.sim.outflow_data[-1] if self.sim.outflow_data else 0:.2f} L/s")
        self.lbl_error.config(text=f"Error: {error:.2f} L")
        self.lbl_mode.config(text=f"Mode: {self.mode_var.get()}")

    def update_setpoint(self):
        sp = self.sp_var.get()
        self.controller.set_setpoint(sp)

    def update_mode(self):
        mode = self.mode_var.get()
        self.controller.set_mode(mode)
        self.lbl_mode.config(text=f"Mode: {mode}")

    def update_pid(self):
        self.controller.kp = self.kp_var.get()
        self.controller.ki = self.ki_var.get()
        self.controller.kd = self.kd_var.get()
        self.controller.integral = 0
        self.controller.prev_error = 0

    def start_sim(self):
        if not self.running:
            self.running = True
            self.sim.running = True
            self.btn_start.config(state=tk.DISABLED)
            self.btn_pause.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.NORMAL)
            self.thread = threading.Thread(target=self.sim.run, args=(300,), daemon=True)
            self.thread.start()

    def pause_sim(self):
        self.sim.paused = not self.sim.paused
        self.btn_pause.config(text="Resume" if self.sim.paused else "Pause")

    def stop_sim(self):
        self.running = False
        self.sim.stop()
        self.btn_start.config(state=tk.NORMAL)
        self.btn_pause.config(state=tk.DISABLED, text="Pause")
        self.btn_stop.config(state=tk.DISABLED)
        self.update_status()
        self.update_plot()

    def reset_sim(self):
        self.stop_sim()
        self.sim.reset()
        self.draw_tank(0)
        self.update_status()
        self.ax1.clear()
        self.ax2.clear()
        self.canvas_plot.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = WaterTankGUI(root)
    root.mainloop()