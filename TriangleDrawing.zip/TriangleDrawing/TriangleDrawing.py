import turtle

turtle.color("green")

for _ in range(3):
    turtle.forward(100)
    turtle.left(120)

turtle.done()
