import tkinter as tk
from tkinter import ttk
import random
import threading
import time
from collections import deque

class Passenger:
    def __init__(self, pid):
        self.id = pid
        self.card = Card()
        self.passed = False

    def __repr__(self):
        return f"P{self.id}({self.card.balance})"

class Card:
    def __init__(self, balance=None):
        if balance is None:
            self.balance = random.randint(0, 100)
        else:
            self.balance = balance
        self.valid = self.balance >= 10

    def deduct(self, amount=10):
        if self.balance >= amount:
            self.balance -= amount
            return True
        return False

class Sensor:
    def __init__(self, gate):
        self.gate = gate
        self.is_triggered = False

    def detect(self, passenger):
        if passenger is not None and passenger.card.valid:
            self.is_triggered = True
            return True
        return False

    def clear(self):
        self.is_triggered = False

class Motor:
    def __init__(self):
        self.is_open = False

    def open(self):
        self.is_open = True

    def close(self):
        self.is_open = False

    def get_state(self):
        return self.is_open

class Gate:
    def __init__(self):
        self.motor = Motor()
        self.sensor = Sensor(self)
        self.queue = deque()
        self.passengers_passed = 0
        self.current_passenger = None
        self.is_processing = False

    def add_passenger(self, passenger):
        self.queue.append(passenger)

    def get_queue_length(self):
        return len(self.queue)

    def process_next(self):
        if self.is_processing or not self.queue:
            return False

        self.current_passenger = self.queue[0]
        if self.sensor.detect(self.current_passenger):
            self.is_processing = True
            self.motor.open()
            return True
        else:
            self.queue.popleft()
            return False

    def complete_pass(self):
        if self.current_passenger is not None:
            self.current_passenger.passed = True
            self.passengers_passed += 1
            self.queue.popleft()
            self.current_passenger = None
            self.sensor.clear()
            self.is_processing = False
            self.motor.close()
            return True
        return False

    def get_status(self):
        if self.motor.is_open:
            return "OPEN"
        else:
            return "CLOSED"

class Simulation:
    def __init__(self, gate, dt=0.5):
        self.gate = gate
        self.dt = dt
        self.running = False
        self.paused = False
        self.passenger_counter = 0
        self.total_processed = 0
        self.time = 0

    def add_random_passenger(self):
        p = Passenger(self.passenger_counter)
        self.passenger_counter += 1
        self.gate.add_passenger(p)
        return p

    def step(self):
        if not self.gate.is_processing and self.gate.queue:
            self.gate.process_next()
        elif self.gate.is_processing:
            self.gate.complete_pass()
            self.total_processed += 1
        self.time += self.dt

    def run(self, duration):
        self.running = True
        while self.running and self.time < duration:
            if not self.paused:
                # add random passenger every ~2 seconds
                if random.random() < 0.3:
                    self.add_random_passenger()
                self.step()
            time.sleep(self.dt)

    def stop(self):
        self.running = False

    def reset(self):
        self.gate.queue.clear()
        self.gate.current_passenger = None
        self.gate.is_processing = False
        self.gate.motor.close()
        self.passenger_counter = 0
        self.total_processed = 0
        self.time = 0

class MetroGateGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Metro Gate Simulator")
        self.root.geometry("800x600")
        self.root.resizable(False, False)

        self.gate = Gate()
        self.sim = Simulation(self.gate)

        self.running = False
        self.thread = None

        self.setup_ui()
        self.update_gui()

    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(left_frame, width=400, height=400, bg="white")
        self.canvas.pack(pady=10)

        right_frame = ttk.Frame(main_frame, padding=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y)

        ttk.Label(right_frame, text="Metro Gate Control", font=("Arial", 14, "bold")).pack(pady=5)

        # Status
        status_frame = ttk.LabelFrame(right_frame, text="Status")
        status_frame.pack(fill=tk.X, pady=5)
        self.lbl_gate = ttk.Label(status_frame, text="Gate: CLOSED")
        self.lbl_gate.pack(anchor="w")
        self.lbl_queue = ttk.Label(status_frame, text="Queue: 0")
        self.lbl_queue.pack(anchor="w")
        self.lbl_passed = ttk.Label(status_frame, text="Passengers Passed: 0")
        self.lbl_passed.pack(anchor="w")
        self.lbl_processing = ttk.Label(status_frame, text="Processing: None")
        self.lbl_processing.pack(anchor="w")

        # Controls
        ctrl_frame = ttk.Frame(right_frame)
        ctrl_frame.pack(fill=tk.X, pady=10)
        self.btn_start = ttk.Button(ctrl_frame, text="Start", command=self.start_sim)
        self.btn_start.pack(side=tk.LEFT, padx=2)
        self.btn_pause = ttk.Button(ctrl_frame, text="Pause", command=self.pause_sim, state=tk.DISABLED)
        self.btn_pause.pack(side=tk.LEFT, padx=2)
        self.btn_stop = ttk.Button(ctrl_frame, text="Stop", command=self.stop_sim, state=tk.DISABLED)
        self.btn_stop.pack(side=tk.LEFT, padx=2)
        self.btn_reset = ttk.Button(ctrl_frame, text="Reset", command=self.reset_sim)
        self.btn_reset.pack(side=tk.LEFT, padx=2)

        # Manual add passenger
        ttk.Button(right_frame, text="Add Passenger", command=self.add_manual_passenger).pack(fill=tk.X, pady=2)

        # Log
        log_frame = ttk.LabelFrame(right_frame, text="Event Log")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.log_text = tk.Text(log_frame, height=10, width=25, state='disabled')
        self.log_text.pack(fill=tk.BOTH, expand=True)

        self.draw_gate()

    def draw_gate(self, state="CLOSED"):
        self.canvas.delete("all")
        W = 400
        H = 400
        # Ground
        self.canvas.create_rectangle(0, 300, W, 320, fill="gray")
        # Left pillar
        self.canvas.create_rectangle(150, 200, 170, 300, fill="darkgray", outline="black")
        # Right pillar
        self.canvas.create_rectangle(230, 200, 250, 300, fill="darkgray", outline="black")
        # Gate doors
        if state == "OPEN":
            self.canvas.create_rectangle(170, 220, 200, 300, fill="green", outline="black")
            self.canvas.create_rectangle(200, 220, 230, 300, fill="green", outline="black")
            self.canvas.create_text(200, 260, text="OPEN", font=("Arial", 16, "bold"), fill="white")
        else:
            self.canvas.create_rectangle(170, 220, 230, 300, fill="red", outline="black")
            self.canvas.create_text(200, 260, text="CLOSED", font=("Arial", 14, "bold"), fill="white")
        # Label
        self.canvas.create_text(200, 340, text="Gate", font=("Arial", 12))

    def log_message(self, msg):
        self.log_text.config(state='normal')
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')

    def add_manual_passenger(self):
        p = Passenger(self.sim.passenger_counter)
        self.sim.passenger_counter += 1
        self.gate.add_passenger(p)
        self.log_message(f"Manual passenger {p.id} added.")
        self.update_gui()

    def update_gui(self):
        state = self.gate.get_status()
        self.draw_gate(state)
        self.lbl_gate.config(text=f"Gate: {state}")
        self.lbl_queue.config(text=f"Queue: {self.gate.get_queue_length()}")
        self.lbl_passed.config(text=f"Passengers Passed: {self.gate.passengers_passed}")
        if self.gate.current_passenger:
            self.lbl_processing.config(text=f"Processing: P{self.gate.current_passenger.id}")
        else:
            self.lbl_processing.config(text="Processing: None")

    def update_loop(self):
        if self.running:
            self.update_gui()
            self.root.after(500, self.update_loop)

    def start_sim(self):
        if not self.running:
            self.running = True
            self.sim.running = True
            self.btn_start.config(state=tk.DISABLED)
            self.btn_pause.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.NORMAL)
            self.log_message("Simulation started.")
            self.thread = threading.Thread(target=self.sim.run, args=(60,), daemon=True)
            self.thread.start()
            self.update_loop()

    def pause_sim(self):
        self.sim.paused = not self.sim.paused
        self.btn_pause.config(text="Resume" if self.sim.paused else "Pause")
        if self.sim.paused:
            self.log_message("Simulation paused.")
        else:
            self.log_message("Simulation resumed.")

    def stop_sim(self):
        self.running = False
        self.sim.stop()
        self.btn_start.config(state=tk.NORMAL)
        self.btn_pause.config(state=tk.DISABLED, text="Pause")
        self.btn_stop.config(state=tk.DISABLED)
        self.log_message("Simulation stopped.")
        self.update_gui()

    def reset_sim(self):
        self.stop_sim()
        self.sim.reset()
        self.log_text.config(state='normal')
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state='disabled')
        self.log_message("Simulation reset.")
        self.update_gui()

if __name__ == "__main__":
    root = tk.Tk()
    app = MetroGateGUI(root)
    root.mainloop()