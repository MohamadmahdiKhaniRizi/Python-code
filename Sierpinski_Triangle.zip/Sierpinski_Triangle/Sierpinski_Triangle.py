import random
import turtle

x = 0 
y = 0

screen = turtle.Screen()
screen.tracer(0)
t = turtle.Turtle()
t.speed(0)
t.hideturtle()
t.penup()

ver = [(0, 200, "blue"),(-200, -200, "red"),(200, -200, "green")]
for vx, vy, color in ver:
    t.goto(vx, vy)
    t.dot(10, color)

for _ in range(10000):
    vx, vy, color = random.choice(ver)
    x = (x + vx) / 2
    y = (y + vy) / 2
    t.goto(x, y)
    t.dot(3, color)

screen.update()
turtle.done()